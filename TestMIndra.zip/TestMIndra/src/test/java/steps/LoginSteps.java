package steps;

import net.thucydides.core.annotations.Step;
import objetos.PaginaAdmin;
import objetos.PaginaLogin;

public class LoginSteps   {
    String actor;

    static PaginaLogin login;
    static PaginaAdmin paginaAdmin;

    @Step
    public static  void Usuario(){
        PaginaLogin.cargarUsuario();
    }
    @Step
    public static void aplicacion() throws Exception {
        // TODO Auto-generated method stub
        login.aplicacion();
    }
    @Step
    public static void loggearse(){
        login.loggearse();
    }

    public static void loginExitoso( ) {
        // TODO Auto-generated method stub
        paginaAdmin.loginExitoso();

    }

}
