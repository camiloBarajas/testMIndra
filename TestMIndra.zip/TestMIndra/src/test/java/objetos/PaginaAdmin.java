package objetos;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;



public class PaginaAdmin {

    WebDriver driver;


    public static void loginExitoso() {
        // TODO Auto-generated method stub
        PaginaLogin login = new PaginaLogin();
        Assert.assertTrue(PaginaLogin.isUserLogged());
        WebElement buttonMenuAdmin = driverChrome.findElement(By.id("menu_admin_viewAdminModule"));
        buttonMenuAdmin.click();


    }
}
