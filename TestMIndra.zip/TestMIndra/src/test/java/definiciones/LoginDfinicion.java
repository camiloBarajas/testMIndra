package definiciones;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.junit.After;
import org.openqa.selenium.WebElement;
import steps.LoginSteps;

public class LoginDfinicion {
    @Steps
    LoginSteps steps;

    @Given("^we are a user$")
    public void we_are_a_user(){

        LoginSteps.Usuario();
    }

    @And("^we enter to application$")
    public void we_enter_to_application() throws Exception{
        System.out.println("Salio de we are the user y entro al And");

        LoginSteps.aplicacion();
    }

    @When("^we make login with user and password$")
    public void  the_login_is_and_password(){
        LoginSteps.loggearse();
    }

    @Then("^the login is successful$")
    public void the_login_is_successfull(){
        LoginSteps.loginExitoso();

    }

    @After
    public void close(){


    }
}
